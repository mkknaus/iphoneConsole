﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace iphoneConsole
{
    class ConsoleReader
    {
        private bool _done = false;
        private Stream _iStream = null; 
        private Stream _oStream = null; 

        const int BUFFER_SIZE = 8124;

        AsyncCallback _readCallBack = null;
 
        Thread _readThread = null;

        public ConsoleReader()
        {
            _done = false;
            _iStream = Console.OpenStandardInput();
            _oStream = Console.OpenStandardOutput();
            _readCallBack = new AsyncCallback(ProcessRead);
            _readThread = new Thread(new ThreadStart(ReadThread));
        }
        
        public void Init()
        {
            _readThread.Start();
        }

        public void Stop()
        {
            _done = true;
        }

        private void ReadThread()
        {
 	        while(!_done)
            {
                 byte[] buff = new byte[8124];
                 _iStream.BeginRead(buff, 0, BUFFER_SIZE, ProcessRead, new AsyncRead(buff, _iStream));
            }
        }

        private void ProcessRead(IAsyncResult ar)
        {
            AsyncRead asyRead = ar.AsyncState as AsyncRead;

            try
            {
                int bRead = asyRead.AStream.EndRead(ar);

                ProcessMessage(asyRead.Data, bRead);

                //_oStream.Write(asyRead.Data, 0, bRead);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void ProcessMessage(byte[] data, int length)
        {
            String msg = System.Text.Encoding.ASCII.GetString(data,0,length);

            if(msg.StartsWith(Command.GET_SERVICES))
            {
                byte[] b = System.Text.Encoding.ASCII.GetBytes("Matt's iPhone\r\n");
                _oStream.Write(b, 0, b.Length);
            }

        }

        static byte[] GetBytes(string str)
        {
            byte[] bytes = new byte[str.Length * sizeof(char)];
            System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }

        static string GetString(byte[] bytes)
        {
            char[] chars = new char[bytes.Length / sizeof(char)];
            System.Buffer.BlockCopy(bytes, 0, chars, 0, bytes.Length);
            return new string(chars);
        }
    }



    public class AsyncRead
    {
        public Byte[] Data { get; set; }
        public Stream AStream { get; set; }

        public AsyncRead(Byte[] buf, Stream str)
        {
            Data = buf;
            AStream = str;
        }
    }
}
