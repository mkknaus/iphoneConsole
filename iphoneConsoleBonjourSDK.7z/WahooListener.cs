﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace WahooListener
{
    class WahooListener
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private static bool _done = false;
        private static bool _listen = false;
        private static Thread _listenThr = null;
        
        private  string _hostName = null;
        private  int _port = -1;
        private  IPAddress _ip = null;

        private UdpClient _udpListener = null;

        public WahooListener(string hostName, int port, IPAddress ip)
        {
            _hostName = hostName;
            _port = port;
            _ip = ip;

            _listen = true;
            _done = false;
        }

        public void Init()
        {
            log.Debug("Init");
            log.Debug("browsing for services...");

            while (!_done)
            {
                Thread.Sleep(250);
            }           

            WakeUp();

            _listenThr = new Thread(new ThreadStart(ListenThread));
            _listenThr.Start();
        }

        private void WakeUp()
        {
            log.Debug("WakeUp");

            UdpClient sender = new UdpClient(_port);

            sender.Connect(_ip, _port);

            // Sends a message to the host to which you have connected.
            Byte[] sendBytes = Encoding.ASCII.GetBytes("{ \"Status\" : \"OK\"}");

            sender.Send(sendBytes, sendBytes.Length);
        }

        private void ListenThread()
        {
            log.Debug("ListenThread");

            _udpListener = new UdpClient(_port + 2);
            IPEndPoint ipe = new IPEndPoint(IPAddress.Broadcast, _port);
            String data = String.Empty;

            byte[] rec_array;
            try
            {
                while (_listen)
                {
                    rec_array = _udpListener.Receive(ref ipe);
                    data = Encoding.ASCII.GetString(rec_array, 0, rec_array.Length);
                    log.DebugFormat("Received a broadcast from {0}. data = {1}", ipe.ToString(), data);
                    
                    Thread.Sleep(250);
                }
            }
            catch (Exception e)
            {
                log.Error(e);
            }
            finally
            {
                try
                {
                    _udpListener.Close();
                }
                catch (Exception e)
                {
                    log.Error(e);
                }
            }

            log.Debug("ListenThread - exiting");
        }

        public void Stop()
        {
            log.Debug("Stop");

            _listen = false;
        }
    }
}
