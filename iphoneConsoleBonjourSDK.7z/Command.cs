﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace iphoneConsole
{
    public class Command
    {
        public static string GET_SERVICES = "GetServices";
        public static string CONNECT = "Connect";
        public static string GET_DATA = "GetData";
    }
}
