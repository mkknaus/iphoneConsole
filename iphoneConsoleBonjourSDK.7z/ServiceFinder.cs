﻿using Bonjour;
using System;
using System.Collections.Generic;
using System.Net;

namespace ServiceFinder
{
    class ServiceFinder : IDisposable
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private const string SVC = "_WahooFitnessBroadcaster._udp.";
        private const string DOMAIN = "local.";

        private Service _service = null;

        private DNSSDService _dnssdSvc = null;
        private DNSSDEventManager _eventManager = null;

        public delegate void ServiceFoundDel(List<String> serviceList);
        public delegate void ServiceResolveDel(Service service);

        public event ServiceFoundDel ServiceFound;
        public event ServiceResolveDel ServiceResolved;

        public ServiceFinder()
        {
            _dnssdSvc = new DNSSDService();
            _eventManager = new DNSSDEventManager();
            _eventManager.ServiceFound += new _IDNSSDEvents_ServiceFoundEventHandler(_eventManager_ServiceFound);
            _eventManager.ServiceLost += new _IDNSSDEvents_ServiceLostEventHandler(_eventManager_ServiceLost);
            _eventManager.ServiceResolved += new _IDNSSDEvents_ServiceResolvedEventHandler(_eventManager_ServiceResolved);
            _eventManager.OperationFailed += new _IDNSSDEvents_OperationFailedEventHandler(_eventManager_OperationFailed);
            _eventManager.QueryRecordAnswered += new _IDNSSDEvents_QueryRecordAnsweredEventHandler(_eventManager_QueryRecordAnswered);
        }

        public void Dispose()
        {

            if (_dnssdSvc != null)
            {
                _dnssdSvc.Stop();
            }

            _eventManager.ServiceFound -= new _IDNSSDEvents_ServiceFoundEventHandler(this._eventManager_ServiceFound);
            _eventManager.ServiceLost -= new _IDNSSDEvents_ServiceLostEventHandler(this._eventManager_ServiceLost);
            _eventManager.ServiceResolved -= new _IDNSSDEvents_ServiceResolvedEventHandler(this._eventManager_ServiceResolved);
            _eventManager.OperationFailed -= new _IDNSSDEvents_OperationFailedEventHandler(this._eventManager_OperationFailed);
            _eventManager.QueryRecordAnswered -= new _IDNSSDEvents_QueryRecordAnsweredEventHandler(this._eventManager_QueryRecordAnswered);

        }

        public void Find()
        {
            _dnssdSvc.Browse(0, 0, SVC, DOMAIN, _eventManager);
        }

        public void Resolve(string name)
        {
            _service = new Service();
            _service.Name = name;

            _dnssdSvc.Resolve(0, 0, name, SVC, DOMAIN, _eventManager);
        }

        private void _eventManager_QueryRecordAnswered(DNSSDService service, DNSSDFlags flags, uint ifIndex, string fullname, DNSSDRRType rrtype, DNSSDRRClass rrclass, object rdata, uint ttl)
        {
            uint bits = BitConverter.ToUInt32((Byte[])rdata, 0);
            _service.IP = new System.Net.IPAddress(bits);

            OnServiceResolved(_service);
        }

        private void _eventManager_OperationFailed(DNSSDService service, DNSSDError error)
        {
            log.ErrorFormat("OperationFailed :  DNSSDError = {0}", error);
        }

        private void _eventManager_ServiceResolved(DNSSDService service, DNSSDFlags flags, uint ifIndex, string fullname, string hostname, ushort port, TXTRecord record)
        {
            _service.HostName = hostname;
            _service.Port = port;

            _dnssdSvc.QueryRecord(0, ifIndex, hostname, DNSSDRRType.kDNSSDType_A, DNSSDRRClass.kDNSSDClass_IN, _eventManager);
        }

        private void _eventManager_ServiceLost(DNSSDService browser, DNSSDFlags flags, uint ifIndex, string serviceName, string regtype, string domain)
        {
            log.Error("Service Lost!");
        }

        private void _eventManager_ServiceFound(DNSSDService browser, DNSSDFlags flags, uint ifIndex, string serviceName, string regtype, string domain)
        {
            OnServiceFound(new List<String>() { serviceName });
        }

        private void OnServiceResolved(Service service)
        {
            if (ServiceResolved != null)
            {
                ServiceResolved(service);
            }
        }

        private void OnServiceFound(List<String> serviceNames)
        {
            if (ServiceFound != null)
            {
                ServiceFound(serviceNames);
            }
        }
    }

    public class Service
    {
        private string _name = null;
        private string _hostName = null;
        private int _port = -1;
        private IPAddress _ip = IPAddress.Any;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string HostName
        {
            get { return _hostName; }
            set { _hostName = value; }
        }
        public int Port
        {
            get { return _port; }
            set { _port = value; }
        }
        public IPAddress IP
        {
            get { return _ip; }
            set { _ip = value; }
        }
    }

    public class ServiceEventArgs : EventArgs
    {
        private Service _service;

        public ServiceEventArgs(Service s)
        {
            _service = s;
        }

        public Service Service
        {
            get { return _service; }
            set { _service = value; }
        }
    }
}
