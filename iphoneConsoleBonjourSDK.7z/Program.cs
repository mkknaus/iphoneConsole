﻿using System;
using System.Threading;

[assembly: log4net.Config.XmlConfigurator(ConfigFile = "Log4Net.config", Watch = true)]

namespace iphoneConsole
{
    class Program
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private static bool _done = false;

        static void Main(string[] args)
        {
            log.Debug("Main");

            AppDomain currentDomain = AppDomain.CurrentDomain;
            currentDomain.UnhandledException += new UnhandledExceptionEventHandler(ExceptionHandler);

            //WahooListener wahooListener = new WahooListener();
            //wahooListener.Init();

            ConsoleReader r = new ConsoleReader();
            r.Init();

            while (true)
            {
                Thread.Sleep(250);
            }

            //r.Stop();
        }

        private static void ExceptionHandler(object sender, UnhandledExceptionEventArgs args)
        {
            Exception e = (Exception) args.ExceptionObject;
            log.ErrorFormat("Uncaught Exception was thrown! message = {0}", e.Message);
        }
    }
}
